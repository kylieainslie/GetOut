### R code from vignette source 'roapkg.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: roapkg.Rnw:54-55
###################################################
options(width=60)


###################################################
### code chunk number 2: roapkg.Rnw:57-80
###################################################
#generate non-outlier data
 set.seed(0)
 sim.data<-matrix(c(rnorm(1000*200,0,1)),nrow=200)
  
#generate outlier gene expression
  y<-matrix(rnorm(200*10,0,1),nrow=200)
  m<-max(sim.data,y)
  c<-c(rep(m,20),rep(0,180))
  test.genes<-y+c
  data<-cbind(test.genes,sim.data)
  
#add column names
  pre<-"test"
  suf<-seq(1:10)
  prefix<-"gene"
  suffix<-seq(1:1000)
  colnames(data)<-c(paste(pre,suf,sep=""),paste(prefix,suffix,sep=""))
  rownames(data)<-c(paste("sample",seq(1:200),sep=""))

#create annotation file
  p<-"gene.symbol"
  s<-seq(1:1010)
  annot<-data.frame(ID=colnames(data),Gene=paste(p,s,sep=""))


###################################################
### code chunk number 3: roapkg.Rnw:84-86
###################################################
library(roa)
uv.outlier(data,num.id=FALSE)


###################################################
### code chunk number 4: roapkg.Rnw:89-91
###################################################
uv.outlier(data,annotation=annot,annID=1,annName=2,common.genes=TRUE,
           num.id=FALSE)


###################################################
### code chunk number 5: roapkg.Rnw:94-95
###################################################
uv.outlier(data,cpmtype="Mann-Whitney",num.id=FALSE)


###################################################
### code chunk number 6: roapkg.Rnw:98-99
###################################################
uv.outlier(data,p=0.95,num.id=FALSE)


###################################################
### code chunk number 7: roapkg.Rnw:102-103
###################################################
uv.outlier(data,cut=0.15,under=TRUE,num.id=FALSE)


###################################################
### code chunk number 8: roapkg.Rnw:108-109
###################################################
uv.outlier(data,num.id=FALSE)


###################################################
### code chunk number 9: roapkg.Rnw:115-116
###################################################
oss(data,num.id=FALSE)


###################################################
### code chunk number 10: roapkg.Rnw:125-126
###################################################
mv.outlier(data,num.id=FALSE)


###################################################
### code chunk number 11: roapkg.Rnw:129-130
###################################################
mv.outlier(data,p=0.95,num.id=FALSE)


###################################################
### code chunk number 12: roapkg.Rnw:136-140
###################################################
out<-mv.outlier(data,num.id=FALSE)
os<-outlying.samples(data,outliers=out[,1])
os$by.outlier[1:25,1:8]
os$sample.ind[1:25,]


###################################################
### code chunk number 13: roapkg.Rnw:148-178
###################################################
#generate normal data
 norm.data<-matrix(c(rnorm(1010*100,0,1)),nrow=100)
  
#generate disease data with 10 outlier genes
  mydata<-matrix(rnorm(1000*100,0,1),nrow=100)
  y<-matrix(rnorm(100*10,0,1),nrow=100)
  m<-max(mydata,y)
  c<-c(rep(m,20),rep(0,80))
  test.genes<-y+c
  dis.data<-cbind(test.genes,mydata)

#add column names
  pre<-"test"
  suf<-seq(1:10)
  prefix<-"gene"
  suffix<-seq(1:1000)
  colnames(dis.data)<-c(paste(pre,suf,sep=""),
                        paste(prefix,suffix,sep=""))
  rownames(dis.data)<-c(paste("dis.sample",seq(1:100),sep=""))

  colnames(norm.data)<-c(paste(pre,suf,sep=""),
                         paste(prefix,suffix,sep=""))
  rownames(norm.data)<-c(paste("norm.sample",seq(1:100),sep=""))
#complete data
  all.data<-rbind(dis.data,norm.data)

#create annotation file
  p<-"gene.symbol"
  s<-seq(1:1010)
  annot<-data.frame(ID=colnames(dis.data),Gene=paste(p,s,sep=""))


###################################################
### code chunk number 14: roapkg.Rnw:182-184
###################################################
example<-mv.outlier2(dis.data,norm.data,all.data,annotation=annot,
              annID=1,annName=2,num.id=FALSE)


###################################################
### code chunk number 15: roapkg.Rnw:187-190
###################################################
os2<-outlying.samples(dis.data,outliers=example[,1])
os2$by.outlier[1:25,1:8]
os2$sample.ind[1:25,]


###################################################
### code chunk number 16: roapkg.Rnw:193-194
###################################################
uv.outlier2(dis.data,norm.data,all.data,num.id=FALSE)


###################################################
### code chunk number 17: roapkg.Rnw:197-198
###################################################
copa2(dis.data,norm.data,all.data,num.id=FALSE,p=0.85)


