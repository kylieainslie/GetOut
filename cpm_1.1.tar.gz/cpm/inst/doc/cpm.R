### R code from vignette source 'cpm.Rnw'

