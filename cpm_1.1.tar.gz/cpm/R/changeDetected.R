changeDetected <- function(cpm) {
    return(cpm@changeDetected)
}
	

